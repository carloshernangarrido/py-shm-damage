# py-shm-damage
Damage detection algorithms for damage detection in Structural Health Monitoring
